Compile main.tex with pdfLaTeX, three passes.
The complete two-column REVTeX manuscript incorporates the slow Gaussian heat-bath mode, slow marked-force response, an explicit operator counterexample and a corrected gap-transfer lemma at equal physical times. The weak-coupling Wilson bounds and nontrivial continuum construction remain open.
The release source tree contains earlier computational and formal-verification materials with their original scope.
