Lattice Mass Gaps and Continuum Criteria for Four-Dimensional Yang-Mills Theory
Research revision v4.41.1

Compile main.tex with pdfLaTeX at least three times.
Release: https://github.com/creelie/4Y-M/releases/tag/v4.41.1
Version DOI: https://doi.org/10.5281/zenodo.24045649
