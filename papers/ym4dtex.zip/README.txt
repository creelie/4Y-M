Compile main.tex with pdfLaTeX at least three times (or use latexmk/Overleaf).
This is the complete 428-page two-column manuscript "Yang-Mills Theory and the Mass Gap".
The permanent work DOI is https://doi.org/10.5281/zenodo.23444338.
The weak-coupling cube estimate (D) and a nontrivial continuum limit (E) remain open.
No Lean files or stale main-manuscript copies are included. Ancillary checks have the scope stated in their outputs.
