Compile main.tex with pdfLaTeX at least three times (or use latexmk/Overleaf).
This is the complete 398-page two-column manuscript, release v4.42.0.
The permanent work DOI is https://doi.org/10.5281/zenodo.23444338.
New results concern off-diagonal certificates, finite-volume Wilson Poisson trials and explicitly stated model inequalities. D and E remain open.
No Lean files or stale main-manuscript copies are included. Ancillary checks have the scope stated in their outputs.
