# AI provenance: Mass Gap of Four-Dimensional Lattice Yang–Mills Theory for Every Compact Simple Gauge Group

Authors:
- Deep Bhattacharjee, corresponding author. ORCID 0000-0003-0466-750X; itsdeep@live.com, d.bhattacharjee@erl-forschung.de. Formerly Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly Heramba Chandra College, 23/49 Gariahat Road, Golpark, Kolkata 700029 (University of Calcutta, 87/1 College Street, Kolkata 700073), West Bengal, India.
- Ushashi Bhattacharya. ORCID 0009-0002-2254-3914. Formerly National Taiwan University, Taipei 106319, Taiwan.
- James Montgomery Lockwood. Independent Researcher, San Antonio, USA; spectralityworkinggroup@gmail.com.

This is the next version of Hexagon preprint 2610.00341, first titled "Mass Gap of Four-Dimensional Lattice Yang–Mills Theory in a Forest Gauge".

- Paper: https://github.com/creelie/4Y-M/blob/main/preprintYangMillsForestGauge/YangMillsForestGauge.pdf
- Source, checks and Lean certificate: https://github.com/creelie/4Y-M, release v3.14.0, https://doi.org/10.5281/zenodo.23724715. The concept record https://doi.org/10.5281/zenodo.23444338 lists every version.

## Result

The gauge of four-dimensional lattice Yang–Mills theory is fixed on a period-two field of straight lines that meets every plaquette in exactly one link. Each free link then has twelve Dobrushin partners. The following results hold at fixed lattice spacing.

- **SU(2).** There is a unique free-boundary state. It is reflection positive, its correlations decay exponentially, and its transfer matrix has a gap. This holds for β_W < 1/3 with single links. With blocks made of the three free links of one plaquette, it holds for β_W ≤ 0.345.
- **SU(3).** The same conclusions hold for β_W ≤ 3/4 with single links, and for β_W ≤ 0.76 with plaquette blocks.
- **Every compact simple group.** The gauge-fixed Hessian is bounded by 29/2, and the least Ricci curvature is κ_G = h^∨/(2ℓ_ρ). Together they give uniqueness, clustering and the explicit gap m_G(β) = arccosh(1 + (κ_G/(N|β|) − 29/2)/12) for N|β| < 2κ_G/29.
- **Averaged cubes.** Take a Dobrushin–Shlosman condition D(n, α) on a cube of n⁴ sites, averaged over its translates. It gives a lattice gap of at least log(1/α)/(2n).
- **Conditional continuum step.** Suppose D(n, α) holds with na ≤ ℓ for a fixed physical length ℓ, uniformly along the continuum tuning. Then every continuum limit has a mass gap of at least log(1/α)/(2ℓ).
- **What the cube estimate requires.** The condition holds at strong coupling for every even n above an explicit size. If it holds, the gauge-fixed links of a cube with the identity outside stay at mean distance at least (1 − α)D/3 from the identity, so for every fixed n it fails once β is large. For SU(2), a configuration in four colours with tetrahedral quaternions sharpens this to mean squared chordal distance at least 2(1 − α), and mean distance at least 1 − α. For every compact simple group, with the Hilbert–Schmidt metric of a nontrivial irreducible representation, the same colouring through the SU(2) of a root shows that the cube keeps at least the fraction 1 − α of the Haar disorder, so the mean distance is at least (1 − α)D/2. For SU(2) there is an exterior, legal at every coupling, under which one line of links has a ten-step gap at most e^20 24^10 b^15 e^(−b/1280); bounds on single lines uniform in the exterior therefore cannot give the condition. For SU(2) the condition needs n⁴ ≥ 2(1−α) β_W/(5 L(β_W)) with L(b) = 1 + log 24 + (3/2) log 9b, and a stationary flux configuration shows that the n² lost in that bound is of the right order. For every SU(N) it needs n⁴ ≥ 2(1−α) β_W/(5 L_N(β_W)) with L_N(b) = 1 + ((N²−1)/2) log(81π²b) + N(N−1) log(12/11), from the Jacobian of the exponential map and a bound on the volume of SU(N).
- **Disorder at every size.** At every n the mean distance of the gauge-fixed links from the identity is at least (1/9)·max(6β_W, 1)^(−1/2), for every exterior.
- **Gaussian benchmark.** For a Gaussian field the averaged cube coefficient is computed exactly: it equals 1 at every size and stiffness when the field is massless, and with a mass m it is at most 1 − (5/6)⁴(mℓ)²/((mℓ)²+160) on cubes of physical side between ℓ/2 and ℓ. The condition therefore asks the gauge-fixed variables for the loss that a mass supplies.
- **Quadratic approximation of the forest gauge.** For the Gaussian field of the Wilson action with the forest links fixed, the indicator of one line is a pure gauge, and the class sums of the cube coefficients are at least the cube size at every n and every stiffness, so the condition fails there. No Bakry–Émery curvature argument for gauge-fixed SU(2) passes β_W = 1/3: at a configuration with one link at −1 the Hessian of the action is −6β_W against Ricci curvature 2.
- **Smoothed observables.** The continuum step also holds for observables smoothed by the spatial gradient flow (Sakai–Sasaki), which is local, gauge covariant and reflection positive and leaves the transfer matrix unchanged up to unitary equivalence.
- **Renormalised flowed observables.** Renormalised by one condition at a single physical separation, the flowed fields have reflection-positive continuum limits along subsequences for every tuning, and the renormalised two-point function is the Laplace transform of a probability measure on [0, ∞]. A nontrivial limit exists if and only if the ratio C(σ)/C(0) of lattice two-point functions at a fixed physical separation and at contact does not tend to zero; that inequality is not proved. In a periodic spatial box the reflected norm C(0) that fixes the renormalisation is strictly positive for product test functions, by Lüscher's strictly positive transfer matrix, so the theorem needs no assumption there. The ratio is that of the smeared packet to its reflected norm, not a point-field ratio at coincidence, which tends to zero even for the free massless field. If the ratio is bounded below, renormalising at that separation gives tight spectral measures with explicit tail, moment and Lipschitz bounds; a one-slab bound ⟨Ψ, (1−T)Ψ⟩ ≤ Ca on the transfer matrix would give the lower bound. Neither the lower bound nor the one-slab bound is proved. For product test functions the packet ratio lies between ratios of correlations of the spatially smeared slice field at two fixed physical separations, and log-convexity carries a bound at one pair to every later pair, so the open input is one inequality liminf D(r′)/D(r) > 0; it holds for the free lattice field, and every bound proved on such ratios is an upper bound.
- **Higher correlations.** If the truncated correlations of the flowed fields obey tree bounds with constants independent of the cutoff, the reflected norm saturates the tree weight and the tree weight has bounded physical volume, then every normalised cumulant is bounded uniformly in the cutoff, all n-point Schwinger functions exist along a subsequence as reflection-positive distributions, and the limit is Gaussian when that physical volume tends to zero. A three-state reflection-positive chain with a fixed gap and a cutoff-independent two-point function has divergent four-point functions, so the two-point function alone cannot replace these hypotheses. The tree bounds are not proved along the continuum tuning.

## Who did what

Text of the contribution: a mix of human-written and AI-generated text.

Human understanding: all parts. The three authors read every proof and approved the final text.

Deep Bhattacharjee chose the problem, directed the work, set the format and ran the computations. The following were produced with AI assistance under his direction: the proofs, the text, the figures, the Lean file, the Python and shell checks, and the reference list. The AI tools were Claude Opus 5.5 in Claude Code, Claude Fable 5.1 with Ultracode, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra.

Every reference was checked against the publisher's, Crossref's or DataCite's record.

The Anaxia engine of the BLLM system first assembled the SU(2) composite (release v3.0.5, doi:10.5281/zenodo.23469389). Release v3.1.0 of the engine records its Yang–Mills runs in a failure log (doi:10.5281/zenodo.23484160). The engine supplied no step of the proofs. The paper says this in its data and code availability section.

## How the result is checked

- **Lean 4 (v4.33.0) with Mathlib.** `YangMills/StrongCoupling/GaugeFix.lean` proves the combinatorics of the line field by `decide`.
- **Exact arithmetic.**
  - The local blocks of the Hessian bound are checked in exact rationals.
  - The curvature table of every compact simple group is checked from the root systems (`strong-coupling/gauge-fixed/checks/groups/ricci.py`, also in `anc/` of the source zip).
- **Ball arithmetic (python-flint, FLINT and Arb).**
  - The SU(3) covers: 2341 boxes at r = 3/2 and 1063 boxes at r = 38/25.
  - The plaquette-block constants for SU(2) and SU(3).
- **Continuum section.** It is analytic. The finite counts of the subsection on the cube estimate (the boundary census, the colouring of the eight lines modulo two, the transverse plaquettes of a line, the discs of the cube-size proposition, the lattice Stokes inequality, the flux configuration, the Gaussian benchmark, the four colours for SU(2), SU(3), SU(4) and SO(3), the Jacobian of the exponential map and the small balls of SU(N), the positive character coefficients of the Wilson weight, and the free-field ratio, the spectral bounds of the shifted renormalisation, the slice-ratio inequalities, the free lattice slice ratio and the three-state chain) are rechecked exactly by `strong-coupling/gauge-fixed/checks/cube/cube_requirements.py` (also in `anc/`, 108828 checks). The cube coefficients of the Gaussian forest gauge for n = 2 to 8, cited in the paper as an illustration, are computed by `gaussian_forest.py` (also in `anc/`). Monte Carlo estimates of the influence coefficients and of ε_V (`influence_mc.py`, `eps_mc.py`, also in `anc/`) are reported in the archive and are not used by any proof.

## What is not claimed

The Clay Millennium problem is not solved. The continuum theorem is conditional on two statements that the paper names and does not prove:
- (D) the cube estimate, uniformly in the lattice spacing;
- (E) the existence of a nontrivial Osterwalder–Schrader continuum limit.

The proofs are written by hand and have not yet been refereed.
