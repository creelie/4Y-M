# Hexagon submission fields (next version of 2610.00341)

Title: Mass Gap of Four-Dimensional Lattice Yang--Mills Theory for Every Compact Simple Gauge Group

Abstract: We fix the gauge of four-dimensional lattice Yang--Mills theory on lines that meet every plaquette once, so that each free link interacts with twelve others. For every compact simple gauge group the theory then has a unique infinite-volume state, exponential clustering and an explicit mass gap at fixed lattice spacing, past the curvature limit of the ungauged theory; for SU(2) and SU(3) the ranges reach beta_W <= 0.345 and beta_W <= 0.76. A mass gap in physical units for every continuum limit follows from one estimate of Dobrushin--Shlosman type in a cube of fixed physical size; that estimate and the existence of the limit remain open. The estimate holds at strong coupling, forces the gauge-fixed variables to be disordered at the scale of the cube, and for SU(N) needs a cube of side at least of order (beta_W/log beta_W)^{1/4}.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Tags: lattice gauge theory, gauge fixing, mass gap, Dobrushin uniqueness, compact simple groups, continuum limit
MSC2020: 81T25; 82B20; 60K35; 81T13; 22E30; 58J50; 65G30
PACS: 11.15.Ha; 05.50.+q; 02.50.Cw; 02.40.Ky

Contributor 1 (submitting, corresponding): Deep Bhattacharjee
- ORCID: 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly, Heramba Chandra College, 23/49 Gariahat Road, Golpark, Kolkata 700029 (University of Calcutta, 87/1 College Street, Kolkata 700073), West Bengal, India
- Email: itsdeep@live.com (secondary d.bhattacharjee@erl-forschung.de; GitHub contact egspl@proton.me, github.com/creelie)

Contributor 2: Ushashi Bhattacharya
- ORCID: 0009-0002-2254-3914
- Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan
- Email: rai.bhattacharya.in@gmail.com

Contributor 3: James Montgomery Lockwood
- Affiliation: Independent Researcher, San Antonio, USA
- Email: spectralityworkinggroup@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.

Provenance statement: Deep Bhattacharjee produced the proofs, the text, the figures, the Lean 4 formalization and the Python and shell checks with AI assistance: Claude Opus 5.5 in Claude Code, Claude Fable 5.1 with Ultracode, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra. All three authors read every proof and approved the final text. The Anaxia engine of the BLLM system first assembled the SU(2) composite (release v3.0.5, doi:10.5281/zenodo.23469389). Release v3.1.0 records its Yang-Mills runs (doi:10.5281/zenodo.23484160). The engine supplied no step of the proofs.

The paper proves the following by hand, at fixed lattice spacing: uniqueness, clustering and a transfer-matrix gap for SU(2) up to beta_W = 0.345, for SU(3) up to beta_W = 0.76, and for every compact simple group when N|beta| < 2 kappa_G/29. It also proves that a Dobrushin-Shlosman estimate in one cube of fixed physical size, uniform along the continuum tuning, gives a mass gap for every continuum limit. It proves what that estimate requires: it holds at strong coupling; it forces the gauge-fixed links of a cube with trivial exterior to stay at mean distance at least (1-alpha)D/3 from the identity, so it fails at every fixed cube size once the coupling is large (for every compact simple group, at least the fraction 1-alpha of the Haar disorder and mean distance (1-alpha)D/2, by four colours); bounds on single lines of links that are uniform in the exterior cannot give it; and for every SU(N) it needs n^4 >= 2(1-alpha) beta_W/(5 L_N(beta_W)); and the quadratic approximation of the forest gauge itself fails it at every n. It also constructs renormalised continuum limits of these smoothed observables along subsequences and reduces their nontriviality to one ratio of lattice two-point functions. In a periodic spatial box it proves that the reflected norm fixing that renormalisation is strictly positive. It shows that a lower bound on that ratio gives tight spectral measures after renormalising at the same separation, and that a one-slab bound on the transfer matrix would give the lower bound; neither is proved. For product test functions it bounds the ratio, in both directions, by ratios of correlations of one spatially smeared slice field at two fixed physical separations, and shows that the free lattice field meets that criterion. It proves that tree bounds on the truncated correlations of the flowed fields give all n-point Schwinger functions as reflection-positive distributions along a subsequence, Gaussian when the tree weight has vanishing physical volume; the tree bounds are not proved. It also proves that the continuum step holds for observables smoothed by the spatial gradient flow, and computes the cube condition exactly for a Gaussian field (it fails at every size when the field is massless and holds at a fixed physical scale when it has a mass). It does not prove the estimate along the continuum tuning or the existence of the continuum limit. It therefore does not solve the Clay Millennium problem, and the paper says so.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1 (Ultracode); OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 (v4.33.0) with Mathlib; Python (NumPy, SciPy, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none.
Formalization: https://github.com/creelie/4Y-M/blob/main/YangMills/StrongCoupling/GaugeFix.lean (release v3.14.0, https://doi.org/10.5281/zenodo.23724715; all versions https://doi.org/10.5281/zenodo.23444338)

Source files or ZIP: YangMillsEveryGroup_final2-tex.zip. It holds the folder YangMillsEveryGroup_final2-tex/ with main.tex, figures/ (six PNG files) and anc/ (ricci.py, make_figures.py, cube_requirements.py, gaussian_forest.py, influence_mc.py, eps_mc.py). It compiles with pdflatex -jobname=output three times; the bibliography is inline, so there is no BibTeX pass. Do not upload the Lean files here.
AI provenance file: AI_PROVENANCE_YangMillsEveryGroup.md
License: CC BY 4.0

Data availability (in the paper): source, checks, certified covers and the Lean 4 certificate in https://github.com/creelie/4Y-M, release v3.14.0.
Ethics approval: not applicable. Funding: none. Competing interests: none.
Upload order: YangMillsEveryGroup_final2.pdf, YangMillsEveryGroup_final2-tex.zip, AI_PROVENANCE_YangMillsEveryGroup.md, HEXAGON_FORM.md (reference only).

Annals of Mathematics: the same PDF and source zip can be sent.
