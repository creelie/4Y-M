# Submission fields, two-column version (version 8 of Hexagon 2610.00341)

Title: Yang–Mills Mass Gap Follows from One Cube

Abstract: We prove that four-dimensional lattice Yang–Mills theory with any compact simple gauge group has a unique infinite-volume state and an explicit transfer-matrix gap in a forest gauge, up to beta_W = 0.348 for SU(2) and beta_W = 0.52 for SU(3), and that a Dobrushin–Shlosman estimate in one cube of fixed physical size, or a spectral gap of the dynamics that resamples such cubes on local gauge-invariant functions, gives a mass gap in every continuum limit. Towards that estimate we factorise the weight of bad islands through the good layers between them and bound the bad side of a projected block average with no hypothesis. The cube estimate itself, the covariance of the labels and the effective action across scales remain open.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Keywords: lattice gauge theory; mass gap; Dobrushin uniqueness; block averages; reflection positivity
MSC2020: Primary 81T25, 82B20; Secondary 81T13, 60K35, 82B26, 22E30
PACS: 11.15.Ha, 11.15.Tk, 05.50.+q, 02.50.Cw

Contributor 1 (submitting, corresponding): Deep Bhattacharjee
- ORCID: 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
- Email: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com; GitHub contact egspl@proton.me (github.com/creelie)

Contributor 2: Ushashi Bhattacharya
- ORCID: 0009-0002-2254-3914
- Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan
- Email: rai.bhattacharya.in@gmail.com

Contributor 3: James Montgomery Lockwood
- Affiliation: Independent Researcher, San Antonio, USA
- Email: spectralityworkinggroup@gmail.com (secondary Blaze61029dogQ@proton.me)

Contributor 4: Tristan Romanov
- Affiliation: Independent Researcher, San Francisco, CA, USA
- Email: romanov360@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.

Provenance statement: Deep Bhattacharjee produced the proofs, the text, the figures and the Python and shell checks with AI assistance (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra). James Montgomery Lockwood contributed the analysis of constrained cubes and its code and the Lean 4 formalisations; Tristan Romanov constructed the certificate of the gauge-fixed Hessian bound and of the constrained quadratic gap. All four authors read every proof and approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the continuum tuning or the existence of a nontrivial continuum limit, so it does not solve the Clay Millennium problem, and it says so. Compared with version 6 (hexagonmath.org/2610.00341v6), the paper adds Section XIII (labels of the blocks, islands of bad blocks, the bad side of a projected block average, the obstructions to the remaining routes, the effective action across one scale), Sections X F to X L (an averaged form of the cube condition, its local form, the couplings where it holds and fails, its neutral part on small tori, its passage to block variables, the upward step and the measures for which the upward step is proved) and Sections XI D, XI H and XI I (the Osterwalder–Schrader axioms for the flowed fields, the limit at separated points of the fields without flow with the inputs it needs, and the conditional chain for every compact simple group), and it proves by hand every constant that version 6 took from computer certificates; the title-page footnote says so.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 with Mathlib; Python (NumPy, SciPy, mpmath, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none.
Formalization: https://github.com/creelie/4Y-M/tree/main/YangMills (release v4.34.0, https://doi.org/10.5281/zenodo.23955046 (all versions https://doi.org/10.5281/zenodo.23444338))

Source files or ZIP: hexagontex.zip. It holds the folder hexagontex/ with main.tex (REVTeX 4-2, two columns, 350 pages), figures/ (thirty-six PNG files; the other figures are TikZ pictures in the source) and anc/ (the Python checks, the figure scripts, the certificate data, and in anc/d5/ and anc/slice/ the certificates and evaluations of the sections on block averages, islands and the open inputs). It compiles with pdflatex three times with no errors, no overfull or underfull boxes and no undefined references; the bibliography is inline, so there is no BibTeX pass.
AI provenance file: ai-provinance-hexagon.md
License: CC BY 4.0

Data availability (in the paper): source, programs of the certified computations and the Lean 4 certificate in https://github.com/creelie/4Y-M, archived on Zenodo (https://doi.org/10.5281/zenodo.23444338).
Ethics approval: not applicable. Funding: none. Competing interests: none.
Upload order: hexagon.pdf, hexagontex.zip, ai-provinance-hexagon.md, hexagon-formfill.md (reference only).


# Submission fields, single-column version (MDPI Preprints, Physical Sciences > Mathematical Physics)

Title: Yang–Mills Mass Gap Follows from One Cube

Abstract: We prove that four-dimensional lattice Yang–Mills theory with any compact simple gauge group has a unique infinite-volume state and an explicit transfer-matrix gap in a forest gauge, up to beta_W = 0.348 for SU(2) and beta_W = 0.52 for SU(3), and that a Dobrushin–Shlosman estimate in one cube of fixed physical size, or a spectral gap of the dynamics that resamples such cubes on local gauge-invariant functions, gives a mass gap in every continuum limit. Towards that estimate we factorise the weight of bad islands through the good layers between them and bound the bad side of a projected block average with no hypothesis. The cube estimate itself, the covariance of the labels and the effective action across scales remain open.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Keywords: lattice gauge theory; mass gap; Dobrushin uniqueness; block averages; reflection positivity
MSC2020: Primary 81T25, 82B20; Secondary 81T13, 60K35, 82B26, 22E30
PACS: 11.15.Ha, 11.15.Tk, 05.50.+q, 02.50.Cw

Contributor 1 (submitting, corresponding): Deep Bhattacharjee
- ORCID: 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
- Email: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com; GitHub contact egspl@proton.me (github.com/creelie)

Contributor 2: Ushashi Bhattacharya
- ORCID: 0009-0002-2254-3914
- Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan
- Email: rai.bhattacharya.in@gmail.com

Contributor 3: James Montgomery Lockwood
- Affiliation: Independent Researcher, San Antonio, USA
- Email: spectralityworkinggroup@gmail.com (secondary Blaze61029dogQ@proton.me)

Contributor 4: Tristan Romanov
- Affiliation: Independent Researcher, San Francisco, CA, USA
- Email: romanov360@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.

Provenance statement: Deep Bhattacharjee produced the proofs, the text, the figures and the Python and shell checks with AI assistance (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra). James Montgomery Lockwood contributed the analysis of constrained cubes and its code and the Lean 4 formalisations; Tristan Romanov constructed the certificate of the gauge-fixed Hessian bound and of the constrained quadratic gap. All four authors read every proof and approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the continuum tuning or the existence of a nontrivial continuum limit, so it does not solve the Clay Millennium problem, and it says so. Compared with version 6 (hexagonmath.org/2610.00341v6), the paper adds Section XIII (labels of the blocks, islands of bad blocks, the bad side of a projected block average, the obstructions to the remaining routes, the effective action across one scale), Sections X F to X L (an averaged form of the cube condition, its local form, the couplings where it holds and fails, its neutral part on small tori, its passage to block variables, the upward step and the measures for which the upward step is proved) and Sections XI D, XI H and XI I (the Osterwalder–Schrader axioms for the flowed fields, the limit at separated points of the fields without flow with the inputs it needs, and the conditional chain for every compact simple group), and it proves by hand every constant that version 6 took from computer certificates; the title-page footnote says so.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 with Mathlib; Python (NumPy, SciPy, mpmath, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none.
Formalization: https://github.com/creelie/4Y-M/tree/main/YangMills (release v4.34.0, https://doi.org/10.5281/zenodo.23955046 (all versions https://doi.org/10.5281/zenodo.23444338))

Source files or ZIP: mdpitex.zip. It holds YangMills.tex (amsart, single column, 543 pages) and thirty-six PNG figures. It compiles with pdflatex three times with no errors, no overfull or underfull boxes and no undefined references; the bibliography is inline.
AI provenance file: ai-provinance-hexagon.md
License: CC BY 4.0

Data availability (in the paper): source, programs of the certified computations and the Lean 4 certificate in https://github.com/creelie/4Y-M, archived on Zenodo (https://doi.org/10.5281/zenodo.23444338).
Ethics approval: not applicable. Funding: none. Competing interests: none.
Upload order: mdpi.pdf, mdpitex.zip, ai-provinance-hexagon.md, hexagon-formfill.md (reference only).
