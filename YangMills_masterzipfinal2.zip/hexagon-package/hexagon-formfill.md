# Submission fields, two-column version (version 5 of Hexagon 2610.00341; earlier title: Explicit Lattice Yang–Mills Mass Gap for Every Compact Simple Group Reducing the Continuum Gap to One Cube)

Title: Yang--Mills Mass Gap on the Lattice and One Cube from the Continuum

Abstract: We prove that four-dimensional lattice Yang–Mills theory with any compact simple gauge group has a unique infinite-volume state and an explicit transfer-matrix gap in a forest gauge, up to beta_W = 0.351 for SU(2) and beta_W = 0.77 for SU(3). We prove that a Dobrushin–Shlosman estimate in one cube of fixed physical size gives a mass gap in every continuum limit, and that the cube needs a side of order (beta_W/log beta_W)^{1/4} lattice spacings. We prove that the curvature of Balaban's block averages costs action independent of the scale, that a translation of the Haar measures makes it rare at every scale for the abelian theory, and that for SU(2) every such translation transported along a forest reaches its constant on the gauge orbit of the vacuum, which fixes the one estimate that remains open.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Keywords: lattice gauge theory; mass gap; Dobrushin uniqueness; block averages; reflection positivity
MSC2020: Primary 81T25, 82B20; Secondary 81T13, 60K35, 82B26, 22E30
PACS: 11.15.Ha, 11.15.Tk, 05.50.+q, 02.50.Cw

Contributor 1 (submitting, corresponding): Deep Bhattacharjee
- ORCID: 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
- Email: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com; GitHub contact egspl@proton.me (github.com/creelie)

Contributor 2: Ushashi Bhattacharya
- ORCID: 0009-0002-2254-3914
- Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan
- Email: rai.bhattacharya.in@gmail.com

Contributor 3: James Montgomery Lockwood
- Affiliation: Independent Researcher, San Antonio, USA
- Email: spectralityworkinggroup@gmail.com (secondary Blaze61029dogQ@proton.me)

Contributor 4: Tristan Romanov
- Affiliation: Independent Researcher, San Francisco, CA, USA
- Email: romanov360@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.

Provenance statement: Deep Bhattacharjee produced the proofs, the text, the figures, the Lean 4 formalization and the Python and shell checks with AI assistance (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra). The programs were written by Deep Bhattacharjee, James Montgomery Lockwood and Tristan Romanov; T. Romanov constructed the certificates of Proposition 88 and Theorem 191. All four authors read every proof and approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the continuum tuning or the existence of the continuum limit, so it does not solve the Clay Millennium problem, and it says so. New in this version: the plaquette blocks to beta_W = 0.351 (SU(2)) and 0.77 (SU(3)), the fixed-set subsection and the coarse-defect subsection with the Haar tilt and its covariant form on a forest.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 (v4.33.0) with Mathlib; Python (NumPy, SciPy, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none.
Formalization: https://github.com/creelie/4Y-M/blob/main/YangMills/StrongCoupling/GaugeFix.lean (release v4.31.0, https://doi.org/10.5281/zenodo.23895262; all versions https://doi.org/10.5281/zenodo.23444338)

Source files or ZIP: hexagontex.zip. It holds the folder hexagontex/ with main.tex (REVTeX 4-2, two columns, 105 pages), figures/ (twenty-two PNG files; three further figures are TikZ pictures in the source) and anc/ (the Python checks, the figure scripts and the certificate data). It compiles with pdflatex -jobname=output three times with no errors, no overfull or underfull boxes and no undefined references; the bibliography is inline, so there is no BibTeX pass.
AI provenance file: ai-provinance-hexagon.md
License: CC BY 4.0

Data availability (in the paper): source, programs of the certified computations and the Lean 4 certificate in https://github.com/creelie/4Y-M, release v4.31.0 (https://doi.org/10.5281/zenodo.23895262).
Ethics approval: not applicable. Funding: none. Competing interests: none.
Upload order: hexagon.pdf, hexagontex.zip, ai-provinance-hexagon.md, hexagon-formfill.md (reference only).


# Submission fields, single-column version (version 5 of Hexagon 2610.00341; MDPI Preprints, Physical Sciences > Mathematical Physics; earlier title: Explicit Lattice Yang–Mills Mass Gap for Every Compact Simple Group Reducing the Continuum Gap to One Cube)

Title: Yang--Mills Mass Gap on the Lattice and One Cube from the Continuum

Abstract: We prove that four-dimensional lattice Yang–Mills theory with any compact simple gauge group has a unique infinite-volume state and an explicit transfer-matrix gap in a forest gauge, up to beta_W = 0.351 for SU(2) and beta_W = 0.77 for SU(3). We prove that a Dobrushin–Shlosman estimate in one cube of fixed physical size gives a mass gap in every continuum limit, and that the cube needs a side of order (beta_W/log beta_W)^{1/4} lattice spacings. We prove that the curvature of Balaban's block averages costs action independent of the scale, that a translation of the Haar measures makes it rare at every scale for the abelian theory, and that for SU(2) every such translation transported along a forest reaches its constant on the gauge orbit of the vacuum, which fixes the one estimate that remains open.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Keywords: lattice gauge theory; mass gap; Dobrushin uniqueness; block averages; reflection positivity
MSC2020: Primary 81T25, 82B20; Secondary 81T13, 60K35, 82B26, 22E30
PACS: 11.15.Ha, 11.15.Tk, 05.50.+q, 02.50.Cw

Contributor 1 (submitting, corresponding): Deep Bhattacharjee
- ORCID: 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
- Email: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com; GitHub contact egspl@proton.me (github.com/creelie)

Contributor 2: Ushashi Bhattacharya
- ORCID: 0009-0002-2254-3914
- Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan
- Email: rai.bhattacharya.in@gmail.com

Contributor 3: James Montgomery Lockwood
- Affiliation: Independent Researcher, San Antonio, USA
- Email: spectralityworkinggroup@gmail.com (secondary Blaze61029dogQ@proton.me)

Contributor 4: Tristan Romanov
- Affiliation: Independent Researcher, San Francisco, CA, USA
- Email: romanov360@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.

Provenance statement: Deep Bhattacharjee produced the proofs, the text, the figures, the Lean 4 formalization and the Python and shell checks with AI assistance (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra). The programs were written by Deep Bhattacharjee, James Montgomery Lockwood and Tristan Romanov; T. Romanov constructed the certificates of Proposition 88 and Theorem 191. All four authors read every proof and approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the continuum tuning or the existence of the continuum limit, so it does not solve the Clay Millennium problem, and it says so. New in this version: the plaquette blocks to beta_W = 0.351 (SU(2)) and 0.77 (SU(3)), the fixed-set subsection and the coarse-defect subsection with the Haar tilt and its covariant form on a forest.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 (v4.33.0) with Mathlib; Python (NumPy, SciPy, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none.
Formalization: https://github.com/creelie/4Y-M/blob/main/YangMills/StrongCoupling/GaugeFix.lean (release v4.31.0, https://doi.org/10.5281/zenodo.23895262; all versions https://doi.org/10.5281/zenodo.23444338)

Source files or ZIP: mdpi-tex.zip. It holds the folder mdpi-tex/ with main.tex (amsart, single column, 161 pages), figures/ (twenty-two PNG files; three further figures are TikZ pictures in the source) and anc/ (the Python checks, the figure scripts and the certificate data). It compiles with pdflatex -jobname=output three times with no errors, no overfull or underfull boxes and no undefined references; the bibliography is inline, so there is no BibTeX pass.
AI provenance file: ai-provinance-hexagon.md
License: CC BY 4.0

Data availability (in the paper): source, programs of the certified computations and the Lean 4 certificate in https://github.com/creelie/4Y-M, release v4.31.0 (https://doi.org/10.5281/zenodo.23895262).
Ethics approval: not applicable. Funding: none. Competing interests: none.
Upload order: mdpi.pdf, mdpi-tex.zip, ai-provinance-hexagon.md, hexagon-formfill.md (reference only).
