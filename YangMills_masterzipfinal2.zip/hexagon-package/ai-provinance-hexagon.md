# AI provenance: Yang–Mills Mass Gap Reduced to One Cube

Authors: Deep Bhattacharjee (corresponding; ORCID 0000-0003-0466-750X), Ushashi Bhattacharya (ORCID 0009-0002-2254-3914), James Montgomery Lockwood, Tristan Romanov. Affiliations and emails as in hexagon-formfill.md.

Version 8 of Hexagon preprint 2610.00341.

- Paper: https://github.com/creelie/4Y-M/blob/main/preprintYangMillsForestGauge/YangMillsForestGauge.pdf
- Source, programs and Lean certificate: https://github.com/creelie/4Y-M, release v4.33.0 (DOI to follow; all versions https://doi.org/10.5281/zenodo.23444338).

## What the paper proves

We prove that four-dimensional lattice Yang–Mills theory with any compact simple gauge group has a unique infinite-volume state and an explicit transfer-matrix gap in a forest gauge, up to beta_W = 0.351 for SU(2) and beta_W = 0.77 for SU(3), and that a Dobrushin–Shlosman estimate in one cube of fixed physical size gives a mass gap in every continuum limit. Towards that estimate we label the blocks of Balaban's averages, prove that the weight of bad islands factorises through kernels on the good layers between them, with cross-ratios exponentially small in the widths of the layers, and give the explicit coupling past which bad islands are rarer than their entropy at every scale up to 1/8 of the scale that defects reach. The averaged covariance of the labels and the effective action across scales remain open.

## How it was made

Deep Bhattacharjee produced the proofs, the text, the figures and the Python and shell checks with AI assistance (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra). James Montgomery Lockwood contributed the analysis of constrained cubes and its code and the Lean 4 formalisations; Tristan Romanov constructed the certificate of the gauge-fixed Hessian bound and of the constrained quadratic gap. All four authors read every proof and approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the continuum tuning or the existence of a nontrivial continuum limit, so it does not solve the Clay Millennium problem, and it says so. Compared with version 6 (hexagonmath.org/2610.00341v6), the paper adds Section 13 (labels of the blocks, islands of bad blocks, the effective action across one scale) and the subsection on the Osterwalder–Schrader axioms for the flowed fields; the title-page footnote says so.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 with Mathlib; Python (NumPy, SciPy, mpmath, python-flint with FLINT and Arb); C; shell.

## What is computed

The constants of the SU(2) and SU(3) plaquette blocks and the gauge-fixed Hessian bound are certified in ball arithmetic (python-flint); the island thresholds and the constants of the sections on block averages and islands are evaluated in exact rational or interval arithmetic (mpmath.iv); Lean 4 with Mathlib checks the combinatorics of the line field and the block gauge, the finite arithmetic of the perturbation propositions and the chain of rational bounds of the SU(2) blocks. Every other step is proved by hand in the text.
