# AI provenance: Yang–Mills Mass Gap Follows from One Cube

Authors: Deep Bhattacharjee (corresponding; ORCID 0000-0003-0466-750X), Ushashi Bhattacharya (ORCID 0009-0002-2254-3914), James Montgomery Lockwood, Tristan Romanov. Affiliations and emails as in hexagon-formfill.md.

Version 8 of Hexagon preprint 2610.00341.

- Paper: https://github.com/creelie/4Y-M/blob/main/preprintYangMillsForestGauge/YangMillsForestGauge.pdf
- Source, programs and Lean certificate: https://github.com/creelie/4Y-M, release v4.34.0, https://doi.org/10.5281/zenodo.23955046 (all versions https://doi.org/10.5281/zenodo.23444338).

## What the paper proves

We prove that four-dimensional lattice Yang–Mills theory with any compact simple gauge group has a unique infinite-volume state and an explicit transfer-matrix gap in a forest gauge, up to beta_W = 0.348 for SU(2) and beta_W = 0.52 for SU(3), and that a Dobrushin–Shlosman estimate in one cube of fixed physical size, or a spectral gap of the dynamics that resamples such cubes on local gauge-invariant functions, gives a mass gap in every continuum limit. Towards that estimate we factorise the weight of bad islands through the good layers between them and bound the bad side of a projected block average with no hypothesis. The cube estimate itself, the covariance of the labels and the effective action across scales remain open.

## How it was made

Deep Bhattacharjee produced the proofs, the text, the figures and the Python and shell checks with AI assistance (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra). James Montgomery Lockwood contributed the analysis of constrained cubes and its code and the Lean 4 formalisations; Tristan Romanov constructed the certificate of the gauge-fixed Hessian bound and of the constrained quadratic gap. All four authors read every proof and approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the continuum tuning or the existence of a nontrivial continuum limit, so it does not solve the Clay Millennium problem, and it says so. Compared with version 6 (hexagonmath.org/2610.00341v6), the paper adds Section XIII (labels of the blocks, islands of bad blocks, the bad side of a projected block average, the obstructions to the remaining routes, the effective action across one scale), Sections X F to X L (an averaged form of the cube condition, its local form, the couplings where it holds and fails, its neutral part on small tori, its passage to block variables, the upward step and the measures for which the upward step is proved) and Sections XI D, XI H and XI I (the Osterwalder–Schrader axioms for the flowed fields, the limit at separated points of the fields without flow with the inputs it needs, and the conditional chain for every compact simple group), and it proves by hand every constant that version 6 took from computer certificates; the title-page footnote says so.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 with Mathlib; Python (NumPy, SciPy, mpmath, python-flint with FLINT and Arb); C; shell.

## What is computed

Every proof is analytic and every number used in a proof is derived in the text. Evaluations for SU(3) in interval arithmetic and computations with certificates checked in exact arithmetic are reported in remarks, and no result uses them. Lean 4 with Mathlib checks the line field, the comparison arithmetic, the coupling lemmas, the finite arithmetic of the island bounds, and the counting and trace identities and constants of the averaged condition and of the derivative in the ends.
