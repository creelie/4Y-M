# Preprint

`YangMillsForestGauge.pdf`: Mass Gap of Four-Dimensional Lattice Yang–Mills Theory for Every Compact Simple Group (97 pages), release v4.27.0. Every release replaces it with the version it accompanies.

All versions of the archive: [doi:10.5281/zenodo.23444338](https://doi.org/10.5281/zenodo.23444338).
