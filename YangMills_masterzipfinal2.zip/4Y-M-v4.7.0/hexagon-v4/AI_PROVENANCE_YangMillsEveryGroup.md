# AI provenance: Mass Gap of Four-Dimensional Lattice Yang–Mills Theory for Every Compact Simple Group

Authors:
- Deep Bhattacharjee, corresponding author. ORCID 0000-0003-0466-750X; d.bhattacharjee@erl-forschung.de, itsdeep@live.com; GitHub contact egspl@proton.me (github.com/creelie). Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India.
- Ushashi Bhattacharya. ORCID 0009-0002-2254-3914. Formerly, National Taiwan University, Taipei 106319, Taiwan.
- James Montgomery Lockwood. Independent Researcher, San Antonio, USA; spectralityworkinggroup@gmail.com (secondary Blaze61029dogQ@proton.me).

Version 4 of Hexagon preprint 2610.00341.

- Paper: https://github.com/creelie/4Y-M/blob/main/preprintYangMillsForestGauge/YangMillsForestGauge.pdf
- Source, programs and Lean certificate: https://github.com/creelie/4Y-M, release v4.7.0, https://doi.org/10.5281/zenodo.23785539 (all versions: https://doi.org/10.5281/zenodo.23444338).

## What the paper proves

The gauge of four-dimensional lattice Yang–Mills theory is fixed on a period-two field of straight lines that meets every plaquette in exactly one link, so that every free link has twelve Dobrushin partners instead of eighteen.

- **Fixed lattice spacing.** A unique free-boundary state, reflection positivity, exponential clustering and a transfer-matrix gap, for SU(2) up to β_W = 0.345, for SU(3) up to β_W = 0.76, and for every compact simple group G when N|β| < 2κ_G/29, with κ_G = h^∨/(2ℓ_ρ) the least Ricci curvature and the explicit gap m_G(β) = arccosh(1 + (κ_G/(N|β|) − 29/2)/12).
- **The continuum step.** A Dobrushin–Shlosman condition on one cube of fixed physical size, uniform along the continuum tuning, gives a mass gap in physical units for every continuum limit; the same holds for observables smoothed by the spatial gradient flow, whose renormalised continuum limits exist along subsequences and are nontrivial exactly when one ratio of two-point functions stays away from zero.
- **The open inputs, measured.** The cube condition holds at strong coupling, fails at every fixed cube size at weak coupling, cannot come from bounds on single lines of links, and for SU(N) needs cubes of side at least of order (β_W/log β_W)^{1/4}; it fails for the abelian Villain theory and for the quadratic approximation of the line gauge.
- **Block averages.** In a gauge whose fixed links are trees inside blocks of side two, the quadratic approximation of the cube condition holds at every coupling for large cubes, and one step of averaging reduces it to the averages. For the group-valued links the straight path between block roots gives a coercivity bound D_v² ≤ 224 Q for every compact group and every field, but it does not compose across scales, and for every compact connected gauge group no continuous covariant block map treats the positions of a block alike. A cut-off of Bałaban's averaging operation is continuous, covariant and coercive for every field, with D² ≤ 1431 Q and coarse energy at most 2956 Q for one step, and agrees with the block averages to first order; it breaks the transverse symmetry only at large fields, and its constants for one step do not compose in general. On fields with values in a maximal torus whose curvature stays small at every scale it composes: the coarse curvature is the mean of the sixteen fine 2×2 fluxes, the energy never increases, and the thin paths are contracted. For every compact group the commutators of the cut-off average are bounded by the square of the local curvature, so it composes on fields whose curvatures at the successive scales have a small sum, with the energy growing at most by a factor exp(12060 σ).

## What is not claimed

The cube estimate along the continuum tuning and the existence of a nontrivial Osterwalder–Schrader continuum limit are not proved. The Clay Millennium problem is not solved, and the paper says so. The proofs are written in full and have not yet been refereed.

## Who did what

Text of the contribution: a mix of human-written and AI-generated text. Human understanding: all parts; the three authors read every proof and approved the final text.

Deep Bhattacharjee chose the problem, directed the work and ran the computations. The proofs, the text, the figures, the Lean file, the Python and shell checks and the reference list were produced with AI assistance under his direction (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra). Every reference was checked against the publisher's, Crossref's or DataCite's record.

The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (release v3.0.5, doi:10.5281/zenodo.23469389; run records in release v3.1.0, doi:10.5281/zenodo.23484160); it supplied no step of the proofs. The block-constrained programme follows J. M. Lockwood's report, and the paper proves it in full.

## How the result is checked

- **Proofs by hand.** Every theorem is proved in the text. The only computations the proofs use are evaluations with rigorous error bounds, in ball arithmetic (python-flint, FLINT and Arb): the SU(3) covers (2341 boxes at r = 3/2 and 1063 at r = 38/25) and the plaquette-block constants.
- **Lean 4 (v4.33.0) with Mathlib.** The combinatorics of the line field and of the block gauge, and the arithmetic joining the analytic steps on perturbations of the action; every theorem on the standard axioms, with no `sorry`.
- **Independent checks** (in `anc/` of the source zip): exact rational checks of the finite counts of the continuum and block sections, the curvature table from the root systems, and numerical checks of the path-block bounds of the slice windings for SU(2) and SU(3), and of the cut-off average. The Monte Carlo estimates in the archive are not used by any proof.
