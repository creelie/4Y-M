# Submission fields, two-column version (version 8 of Hexagon 2610.00341)

Title: One Cube Estimate Implies the Yang–Mills Mass Gap

Abstract: We prove that four-dimensional lattice Yang–Mills theory with any compact simple gauge group has a unique infinite-volume state and a mass gap at strong coupling, and that one averaged estimate in a single cube of fixed physical size gives a mass gap to every continuum limit. For SU(2) the block variables approach the Haar measure in every representation as the coupling is tuned to the continuum, and this proves the estimate at the coarsest scale on every torus of side up to 4^k after k blocking steps. The estimate along the whole tuning remains open.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Keywords: lattice gauge theory; mass gap; Dobrushin uniqueness; block-spin renormalisation; reflection positivity
MSC2020: Primary 81T25, 82B20; Secondary 81T13, 60K35, 82B26, 22E30, 43A77
PACS: 11.15.Ha, 11.15.Tk, 05.50.+q, 05.10.Cc

Contributor 1 (submitting, corresponding): Deep Bhattacharjee
- ORCID: 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
- Email: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com; GitHub contact egspl@proton.me (github.com/creelie)

Contributor 2: Ushashi Bhattacharya
- ORCID: 0009-0002-2254-3914
- Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan
- Email: rai.bhattacharya.in@gmail.com

Contributor 3: James Montgomery Lockwood
- Affiliation: Independent Researcher, San Antonio, USA
- Email: spectralityworkinggroup@gmail.com (secondary Blaze61029dogQ@proton.me)

Contributor 4: Tristan Romanov
- Affiliation: Independent Researcher, San Francisco, CA, USA
- Email: romanov360@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.

Provenance statement: Deep Bhattacharjee conceived the project and, with the help of AI agents working under his direction (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra), made its constructions and proved its main results: the forest gauge on the period-two line field and the free-boundary state with its transfer-matrix gap at strong coupling; the plaquette blocks of SU(2) and SU(3) with their constants proved by hand; the reduction of the mass gap to one averaged estimate in a cube of fixed physical size; the labels of Bałaban's blocks and the islands of bad blocks; the averaged condition, its descent to block variables, the upward step and the split inequality; the single-link coefficients across scales, the forces in the fibre law, the smoothing along the paths for SU(2) and the row sums of the Gaussian model; and the conditional chain for every compact simple group. He wrote the programs of the certified computations and the paper, and checked every statement. Ushashi Bhattacharya checked the proofs and the references and edited the text. James Montgomery Lockwood contributed the analysis of constrained cubes and its code and Lean 4 formalisations; Tristan Romanov contributed the certified bound on the forest-gauge Hessian and the research continuation on which Section XIII is built, with four Lean 4 modules. All four authors approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the whole continuum tuning or the existence of a nontrivial continuum limit, so it does not solve the Clay Millennium problem, and it says so. Compared with version 6 (hexagonmath.org/2610.00341v6), the paper adds Section XIII (labels of the blocks, islands of bad blocks, the bad side of a projected block average, the obstructions to the remaining routes, the effective action across one scale), Sections X F to X R (an averaged form of the cube condition, its local form, the couplings where it holds and fails, its neutral part on small tori, its passage to block variables, the upward step, the measures for which it holds, the split inequality at strong coupling, the condition at the coarsest scale, the coefficients across scales, the forces in the fibre law, the smoothing along the paths and the order of the row sums of the Gaussian model), Sections XI D, XI H and XI I (the Osterwalder–Schrader axioms for the flowed fields, the limit at separated points of the fields without flow with the inputs it needs, and the conditional chain for every compact simple group) and the concluding Section XIV, and it proves by hand every constant that version 6 took from computer certificates; the title-page footnote says so.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 with Mathlib; Python (NumPy, SciPy, mpmath, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none.
Formalization: https://github.com/creelie/4Y-M/tree/main/YangMills (release v4.36.0, https://doi.org/10.5281/zenodo.23963469 (all versions https://doi.org/10.5281/zenodo.23444338))

Source files or ZIP: hexagontex.zip. It holds the folder hexagontex/ with main.tex (REVTeX 4-2, two columns, 382 pages), figures/ (41 PNG files; the other figures are TikZ pictures in the source) and anc/ (the Python checks, the figure scripts, the certificate data, and in anc/d5/ and anc/slice/ the certificates and evaluations of the sections on block averages, islands and the open inputs). It also holds main.aux and output.aux (the cross-references for the jobnames main and output), so it compiles in one pdflatex pass of about 13 s, with no errors, no overfull or underfull boxes and no undefined references; the bibliography is inline, so there is no BibTeX pass.
AI provenance file: ai-provinance-hexagon.md
License: CC BY 4.0

Data availability (in the paper): source, programs of the certified computations and the Lean 4 certificate in https://github.com/creelie/4Y-M, archived on Zenodo (https://doi.org/10.5281/zenodo.23444338).
Ethics approval: not applicable. Funding: none. Competing interests: none.
Upload order: hexagon.pdf, hexagontex.zip, ai-provinance-hexagon.md, hexagon-formfill.md (reference only).


# Submission fields, single-column version (MDPI Preprints, Physical Sciences > Mathematical Physics)

Title: One Cube Estimate Implies the Yang–Mills Mass Gap

Abstract: We prove that four-dimensional lattice Yang–Mills theory with any compact simple gauge group has a unique infinite-volume state and a mass gap at strong coupling, and that one averaged estimate in a single cube of fixed physical size gives a mass gap to every continuum limit. For SU(2) the block variables approach the Haar measure in every representation as the coupling is tuned to the continuum, and this proves the estimate at the coarsest scale on every torus of side up to 4^k after k blocking steps. The estimate along the whole tuning remains open.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Keywords: lattice gauge theory; mass gap; Dobrushin uniqueness; block-spin renormalisation; reflection positivity
MSC2020: Primary 81T25, 82B20; Secondary 81T13, 60K35, 82B26, 22E30, 43A77
PACS: 11.15.Ha, 11.15.Tk, 05.50.+q, 05.10.Cc

Contributor 1 (submitting, corresponding): Deep Bhattacharjee
- ORCID: 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
- Email: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com; GitHub contact egspl@proton.me (github.com/creelie)

Contributor 2: Ushashi Bhattacharya
- ORCID: 0009-0002-2254-3914
- Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan
- Email: rai.bhattacharya.in@gmail.com

Contributor 3: James Montgomery Lockwood
- Affiliation: Independent Researcher, San Antonio, USA
- Email: spectralityworkinggroup@gmail.com (secondary Blaze61029dogQ@proton.me)

Contributor 4: Tristan Romanov
- Affiliation: Independent Researcher, San Francisco, CA, USA
- Email: romanov360@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.

Provenance statement: Deep Bhattacharjee conceived the project and, with the help of AI agents working under his direction (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra), made its constructions and proved its main results: the forest gauge on the period-two line field and the free-boundary state with its transfer-matrix gap at strong coupling; the plaquette blocks of SU(2) and SU(3) with their constants proved by hand; the reduction of the mass gap to one averaged estimate in a cube of fixed physical size; the labels of Bałaban's blocks and the islands of bad blocks; the averaged condition, its descent to block variables, the upward step and the split inequality; the single-link coefficients across scales, the forces in the fibre law, the smoothing along the paths for SU(2) and the row sums of the Gaussian model; and the conditional chain for every compact simple group. He wrote the programs of the certified computations and the paper, and checked every statement. Ushashi Bhattacharya checked the proofs and the references and edited the text. James Montgomery Lockwood contributed the analysis of constrained cubes and its code and Lean 4 formalisations; Tristan Romanov contributed the certified bound on the forest-gauge Hessian and the research continuation on which Section XIII is built, with four Lean 4 modules. All four authors approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the whole continuum tuning or the existence of a nontrivial continuum limit, so it does not solve the Clay Millennium problem, and it says so. Compared with version 6 (hexagonmath.org/2610.00341v6), the paper adds Section XIII (labels of the blocks, islands of bad blocks, the bad side of a projected block average, the obstructions to the remaining routes, the effective action across one scale), Sections X F to X R (an averaged form of the cube condition, its local form, the couplings where it holds and fails, its neutral part on small tori, its passage to block variables, the upward step, the measures for which it holds, the split inequality at strong coupling, the condition at the coarsest scale, the coefficients across scales, the forces in the fibre law, the smoothing along the paths and the order of the row sums of the Gaussian model), Sections XI D, XI H and XI I (the Osterwalder–Schrader axioms for the flowed fields, the limit at separated points of the fields without flow with the inputs it needs, and the conditional chain for every compact simple group) and the concluding Section XIV, and it proves by hand every constant that version 6 took from computer certificates; the title-page footnote says so.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 with Mathlib; Python (NumPy, SciPy, mpmath, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none.
Formalization: https://github.com/creelie/4Y-M/tree/main/YangMills (release v4.36.0, https://doi.org/10.5281/zenodo.23963469 (all versions https://doi.org/10.5281/zenodo.23444338))

Source files or ZIP: mdpitex.zip (YangMills.tex, amsart, one column, 594 pages, with the 41 PNG figures it uses and YangMills.aux, so that it compiles in one pdflatex pass of about 14 s). It compiles with no errors, no overfull or underfull boxes and no undefined references; the bibliography is inline.
AI provenance file: ai-provinance-hexagon.md
License: CC BY 4.0

Data availability (in the paper): source, programs of the certified computations and the Lean 4 certificate in https://github.com/creelie/4Y-M, archived on Zenodo (https://doi.org/10.5281/zenodo.23444338).
Ethics approval: not applicable. Funding: none. Competing interests: none.
Upload order: mdpi.pdf, mdpitex.zip, ai-provinance-hexagon.md, hexagon-formfill.md (reference only).
