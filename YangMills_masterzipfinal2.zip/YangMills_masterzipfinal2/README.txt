Lattice Yang-Mills theory: master archive (release v3.0.1)
Deep Bhattacharjee (ORCID 0000-0003-0466-750X) and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914)

4Y-M-v3.0.1/   the repository at release v3.0.1 (doi:10.5281/zenodo.23484057;
               all versions: doi:10.5281/zenodo.23444338): papers, checks, Lean.
hexagon/       Hexagon package of "Mass Gap of Four-Dimensional Lattice Yang-Mills
               Theory in a Forest Gauge": final PDF, TeX zip (PNG figures; builds
               with pdflatex on TeX Live 2026 in under a second per pass, 13 pages),
               AI provenance and submission form.
journal/       journal packages: forest-gauge paper and "Mass Gap of Lattice
               Yang-Mills Theory up to the Dobrushin Ceiling" (PDF, TeX zip,
               arXiv tarball), and the no-go paper "Spacing-Uniform Lattice
               Inequalities Cannot Produce the Yang-Mills Mass Gap" (PDF).

These are lattice results at fixed spacing. The continuum Yang-Mills mass gap
(the Clay problem) is not claimed.
