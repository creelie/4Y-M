Lattice Yang-Mills theory: master archive (release v3.3.1)
Deep Bhattacharjee (ORCID 0000-0003-0466-750X) and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914)

4Y-M-v3.3.1/   the repository at release v3.3.1 (doi:10.5281/zenodo.23490028;
               the paper prints the DOI of v3.3.0, doi:10.5281/zenodo.23490004;
               all versions: doi:10.5281/zenodo.23444338): papers, checks, Lean.
               The previous master zip is left out of this copy.
hexagon/       Hexagon package of "Mass Gap of Four-Dimensional Lattice Yang-Mills
               Theory in a Forest Gauge": final PDF (19 pages), TeX zip (PNG
               figures; pdflatex three times, no BibTeX), arXiv tarball, AI
               provenance and submission form. New in this version: the
               plaquette blocks for SU(3), which raise the gap at beta_W = 3/4
               from 1.1e-4 to 0.0177 (Theorem 6, Section VIII).
journal/       journal packages: forest-gauge paper for Communications in
               Mathematical Physics (amsart, 28 pages; PDF, TeX zip, notes in
               YangMillsForestGauge_JOURNAL.md, and the REVTeX arXiv tarball),
               "Mass Gap of Lattice Yang-Mills Theory up to the Dobrushin
               Ceiling" (PDF, TeX zip, arXiv tarball), and the no-go paper
               "Spacing-Uniform Lattice Inequalities Cannot Produce the
               Yang-Mills Mass Gap" (PDF).

These are lattice results at fixed spacing. The continuum Yang-Mills mass gap
(the Clay problem) is not claimed.
