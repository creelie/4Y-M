Lattice Yang-Mills theory: master archive (release v3.2.1)
Deep Bhattacharjee (ORCID 0000-0003-0466-750X) and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914)

4Y-M-v3.2.1/   the repository at release v3.2.1 (doi:10.5281/zenodo.23487558;
               the paper prints the DOI of v3.2.0, doi:10.5281/zenodo.23487516;
               all versions: doi:10.5281/zenodo.23444338): papers, checks, Lean.
hexagon/       Hexagon package of "Mass Gap of Four-Dimensional Lattice Yang-Mills
               Theory in a Forest Gauge": final PDF (17 pages), TeX zip (PNG
               figures; pdflatex three times, no BibTeX), arXiv tarball, AI
               provenance and submission form. SU(2) now passes the single-link
               ceiling 1/3: plaquette blocks give the gap for beta_W <= 0.345.
journal/       journal packages: forest-gauge paper for Communications in
               Mathematical Physics (amsart, 25 pages; PDF, TeX zip, notes in
               YangMillsForestGauge_JOURNAL.md, and the REVTeX arXiv tarball),
               "Mass Gap of Lattice Yang-Mills Theory up to the Dobrushin
               Ceiling" (PDF, TeX zip, arXiv tarball), and the no-go paper
               "Spacing-Uniform Lattice Inequalities Cannot Produce the
               Yang-Mills Mass Gap" (PDF).

These are lattice results at fixed spacing. The continuum Yang-Mills mass gap
(the Clay problem) is not claimed.
