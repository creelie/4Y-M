# Preprints

The current PDF of each paper of this repository. Every release replaces these files with the version it accompanies.

| File | Paper | Release |
|---|---|---|
| `YangMillsForestGauge.pdf` | Mass Gap of Four-Dimensional Lattice Yang–Mills Theory in a Forest Gauge (REVTeX, 19 pages) | v3.3.0, [doi:10.5281/zenodo.23490004](https://doi.org/10.5281/zenodo.23490004) |
| `YangMillsForestGauge_CMP.pdf` | the same paper in the format for Communications in Mathematical Physics (amsart, 28 pages) | v3.3.0 |
| `YangMillsDobrushinCeiling.pdf` | Mass Gap of Lattice Yang–Mills Theory up to the Dobrushin Ceiling | v2.0.2, [doi:10.5281/zenodo.23449466](https://doi.org/10.5281/zenodo.23449466) |

All versions of the archive: [doi:10.5281/zenodo.23444338](https://doi.org/10.5281/zenodo.23444338).
