# Journal submission

Target: *Communications in Mathematical Physics* (Springer). The paper proves uniqueness, exponential decay and a transfer-matrix gap for four-dimensional lattice Yang–Mills theory at explicit couplings, by Dobrushin and Bakry–Émery arguments after a gauge fixing. Rigorous lattice gauge theory of this kind, from Osterwalder–Seiler and Bałaban onwards, is the journal's field.
Alternatives: *Annales Henri Poincaré* (Springer), *Journal of Statistical Physics* (Springer).

## Files

- `YangMillsForestGauge_final2.pdf`: the paper in the AMS article class, one column, A4, 25 pages (version 3.2.1 of the archive).
- `YangMillsForestGauge_final2-tex.zip`: `main.tex` and `figures/*.png`. Run pdflatex three times; there is no BibTeX run (the references are inline, in the Springer basic style that CMP prints, numbered alphabetically). Tested in a clean folder (TeX Live 2023 in this build): no errors, no overfull or underfull boxes, no undefined references.

This is a separate build from the Hexagon package (`v3.2-hexagon/`, REVTeX two-column, 17 pages): different class, layout, reference style and front matter. Sizes: PDF 907,331 bytes here against 625,721 in the Hexagon package; tex zip 337,586 against 338,226.

Class: the source uses `amsart`. The only CMP class on CTAN is the 1990s `svjour`/`svcmp.clo`; Springer now typesets from its own Springer Nature template, which could not be downloaded here. The paper uses only standard environments, so the move to the template at acceptance is mechanical.

## Metadata

Title: Mass Gap of Four-Dimensional Lattice Yang–Mills Theory in a Forest Gauge
Authors: Deep Bhattacharjee (corresponding; itsdeep@live.com, d.bhattacharjee@erl-forschung.de; ORCID 0000-0003-0466-750X) and Ushashi Bhattacharya (rai.bhattacharya.in@gmail.com; ORCID 0009-0002-2254-3914)
MSC2020: 81T25, 82B20 (primary); 60K35, 81T13, 22E30, 58J50, 65G30
Keywords: Lattice gauge theory, gauge fixing, Dobrushin uniqueness, mass gap

Declarations (in the paper): funding none; competing interests none. The data availability section names the archive (Zenodo, release 3.2.0, doi:10.5281/zenodo.23487516, and 3.2.1, which prints it, doi:10.5281/zenodo.23487558; all versions doi:10.5281/zenodo.23444338; repository creelie/4Y-M), the engine Anaxia (BLLM release 3.0.5, doi:10.5281/zenodo.23469389, which assembled the first composite behind Theorem 1.1; release 3.1.0, doi:10.5281/zenodo.23484160, which records the Yang–Mills runs in its failure log, whose last entry is the change to blocks of several links; the plaquette blocks were found and checked by the authors) and the AI assistance from Claude (Anthropic). The footnote to Theorem 1.1 says what the engine did and did not do.

## Cover letter points

- The gauge is fixed on a field of straight lines that meets every plaquette in exactly one link, so every free link has twelve partners instead of eighteen.
- SU(2): uniqueness, decay and a transfer-matrix gap m ≥ −log(3β_W) for β_W < 1/3 (Theorem 1.1). The sharp-quarter Dobrushin bound of our earlier paper gave β_W < 2/9 without gauge fixing.
- 1/3 is the limit of every single-link Kantorovich argument in any forest gauge (Theorem 1.2).
- SU(2) past 1/3: blocks made of the three free links of one plaquette of the gauge give uniqueness, decay and a gap m ≥ −(1/2) log α(β_W) for β_W ≤ 0.345 (Theorem 1.3, Section 5), with constants of the von Mises–Fisher law on S^3 certified in ball arithmetic.
- Curvature: in the gauge the Hessian of the action is at most 29/2 against the sharp 16 without it, which gives every SU(N) for |β| < 1/29, past the 1/32 that no ungauged curvature argument can pass (Theorem 1.4).
- SU(3): the same conclusions for β_W ≤ 3/4 with m ≥ −log(1.3332 β_W) (Theorem 1.5), against 9/32 before. The analytic part is a spectral-gap bound by Bochner's formula with a cross term, a corrector chosen among polynomials of degree two in the matrix entries and the character expansion of the one-link moments; the last step evaluates the resulting bound on 2341 boxes of staple sums in ball arithmetic, all below 0.999887.
- Section 8 says where the methods stop: single-link SU(3) arguments at or below β_W ≈ 0.77 (the corrector of degree two reaches 1.0018 at r = 1.54 in floating point, close to the Galerkin values), and SU(2) plaquette blocks near β_W ≈ 0.357 (a floating-point search, Remark 5.7); beyond these, larger blocks are needed.
- The paper does not claim the continuum mass gap. Every bound is uniform in lattice units, and the region between these couplings and the scaling region stays open.

## Before submitting

- CMP considers only papers not under consideration elsewhere. Posting a preprint is fine; if the Hexagon copy is a journal submission rather than a preprint, settle that first.
- The earlier paper cited as [BB26a] (the sharp quarter and the curvature ceiling) is on Zenodo and not yet refereed; the referee will need it.
- Suggested referees: none proposed.
