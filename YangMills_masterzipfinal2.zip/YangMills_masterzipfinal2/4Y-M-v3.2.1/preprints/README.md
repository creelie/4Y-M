# Preprints

The current PDF of each paper of this repository. Every release replaces these files with the version it accompanies.

| File | Paper | Release |
|---|---|---|
| `YangMillsForestGauge.pdf` | Mass Gap of Four-Dimensional Lattice Yang–Mills Theory in a Forest Gauge (REVTeX, 17 pages) | v3.2.0, [doi:10.5281/zenodo.23487516](https://doi.org/10.5281/zenodo.23487516) |
| `YangMillsForestGauge_CMP.pdf` | the same paper in the format for Communications in Mathematical Physics (amsart, 25 pages) | v3.2.0 |
| `YangMillsDobrushinCeiling.pdf` | Mass Gap of Lattice Yang–Mills Theory up to the Dobrushin Ceiling | v2.0.2, [doi:10.5281/zenodo.23449466](https://doi.org/10.5281/zenodo.23449466) |

All versions of the archive: [doi:10.5281/zenodo.23444338](https://doi.org/10.5281/zenodo.23444338).
