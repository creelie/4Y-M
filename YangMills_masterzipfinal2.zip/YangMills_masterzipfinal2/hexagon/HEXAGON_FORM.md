# Hexagon submission fields

Title: Mass Gap of Four-Dimensional Lattice Yang--Mills Theory in a Forest Gauge

Abstract: We fix the gauge of four-dimensional lattice Yang--Mills theory on a field of straight lines that meets every plaquette in exactly one link, so that each free link interacts with twelve others instead of eighteen. In this gauge the theory has a unique infinite-volume state with exponential decay of correlations and a positive mass gap at fixed lattice spacing, for SU(2) beyond the limit of every single-link argument in a gauge of this kind, by blocks made of the three free links of a plaquette, for every SU(N) beyond the curvature limit of the ungauged theory, and for SU(3) on a range more than two and a half times as large as was known before.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Tags: lattice gauge theory, gauge fixing, mass gap, Dobrushin uniqueness, Bakry-Emery curvature, ball arithmetic, plaquette blocks
MSC2020: 81T25; 82B20; 60K35; 81T13; 22E30; 58J50; 65G30

Contributor 1 (submitting): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly, University of Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal, India; itsdeep@live.com (second address d.bhattacharjee@erl-forschung.de)
Contributor 2: Ushashi Bhattacharya; ORCID 0009-0002-2254-3914; affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan; rai.bhattacharya.in@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: "All parts" only after both authors have read every proof; otherwise "Some parts, but not all".

Provenance statement: The proofs, the text, the figures, the Lean 4 formalization, the Python and shell checks the certified SU(3) computation and the plaquette-block constants were carried out by Deep Bhattacharjee with AI assistance (Claude, Anthropic) in the Claude Code environment; the Anaxia engine of the BLLM system (release v3.0.5, doi:10.5281/zenodo.23469389) first assembled the SU(2) composite, as the paper states in a footnote; release v3.1.0 of the engine (doi:10.5281/zenodo.23484160) records the Yang-Mills runs in its failure log, whose last Yang-Mills entry is the change from single links to blocks of several links, and supplied no step of the proofs; the plaquette blocks and their constants were found and checked by the authors. The paper proves, by hand: a period-two field of straight lines in Z^4 that meets every plaquette in exactly one link, so that every free link has twelve Dobrushin partners; in the gauge fixed on those links, a unique free-boundary state, reflection positive, with exponential decay and a transfer-matrix gap m >= -log(3 beta_W) for four-dimensional SU(2) at beta_W < 1/3, the ceiling of single-link Dobrushin after any forest gauge fixing; a gauge-fixed Hessian bound 29/2 (against 16) for every SU(N) and SO(N), giving Bakry-Emery, decay and a gap for |beta| < 1/29; for four-dimensional SU(2) past one third, with blocks made of the three free links of one plaquette of the gauge (sixteen block plaquettes modulo two, found by an exact-cover search), a block Dobrushin bound whose constants (Hessian eigenvalues and third derivative of the log partition function of the von Mises-Fisher law on S^3) are certified in ball arithmetic, giving uniqueness, decay and a gap m >= -(1/2) log alpha(beta_W) for beta_W <= 0.345 (alpha(1/3) <= 0.95602, alpha(0.345) <= 0.99729); and for four-dimensional SU(3) the same conclusions for beta_W <= 3/4 with m >= -log(1.3332 beta_W), from an analytic spectral-gap bound for the one-link measure and a corrector of degree two in the matrix entries evaluated at every staple sum on 2341 boxes certified in ball arithmetic. The combinatorics of the line field are proved in Lean 4 by decide (seven theorems, axioms propext at most). This is a result about lattice Yang-Mills theory at fixed lattice spacing; it does not prove the continuum Yang-Mills existence and mass-gap problem of the Clay Institute, and the paper says so. Both authors approved the final version.

Tools used: Anthropic - Claude (Claude Code); BLLM Anaxia engine v3.0.5 and v3.1.0; Lean community - Lean 4 (v4.33.0) with Mathlib; Python (NumPy, SciPy, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none (not posted on arXiv).
Formalization: https://github.com/creelie/4Y-M/blob/main/YangMills/StrongCoupling/GaugeFix.lean (archived on Zenodo with the repository; release v3.2.1 https://doi.org/10.5281/zenodo.23487558; all versions at https://doi.org/10.5281/zenodo.23444338)

Source files or ZIP: YangMillsForestGauge_final2-tex.zip (the folder YangMillsForestGauge_final2-tex/ with main.tex and figures/ as four PNG files; eight entries; compiles with pdflatex three times, no BibTeX pass). Do not upload the Lean files here.
AI provenance files: AI_PROVENANCE_YangMillsForestGauge.md
License: CC BY 4.0

Data availability (in the paper): LaTeX source, checks, the certified SU(3) cover and the Lean 4 certificate in https://github.com/creelie/4Y-M, archived on Zenodo (release v3.2.0, doi:10.5281/zenodo.23487516; release v3.2.1, which prints that DOI, doi:10.5281/zenodo.23487558; all versions at doi:10.5281/zenodo.23444338); the folder preprintYangMillsForestGauge holds the PDF only.
AI disclosure (in the paper, Data and code availability): Deep Bhattacharjee carried out the computations and the Lean, Python and shell checks with AI assistance from Claude (Anthropic); the first composite behind Theorem 1 was assembled by the Anaxia engine of the BLLM system, release v3.0.5, and release v3.1.0 records the engine's Yang-Mills runs in its failure log; both authors approved the final text. No separate AI declaration.
Funding: none. Competing interests: none.
Upload order: YangMillsForestGauge_final2.pdf, YangMillsForestGauge_final2-tex.zip, AI_PROVENANCE_YangMillsForestGauge.md, HEXAGON_FORM.md (for your reference only).
