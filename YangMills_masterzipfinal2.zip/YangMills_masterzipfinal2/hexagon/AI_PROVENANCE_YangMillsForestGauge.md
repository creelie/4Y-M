# AI provenance: Mass Gap of Four-Dimensional Lattice Yang–Mills Theory in a Forest Gauge

Authors: Deep Bhattacharjee (corresponding author, ORCID 0000-0003-0466-750X;
formerly EGSPL, Bhubaneswar, Odisha 751030, India, and formerly University of
Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal,
India) and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914; formerly National
Taiwan University, Taipei 106319, Taiwan).

- Paper: https://github.com/creelie/4Y-M/blob/main/preprintYangMillsForestGauge/YangMillsForestGauge.pdf
- Notes, checks and the Lean certificate: https://github.com/creelie/4Y-M (release v3.3.0 https://doi.org/10.5281/zenodo.23490004, v3.3.1 https://doi.org/10.5281/zenodo.23490028; concept record https://doi.org/10.5281/zenodo.23444338, which lists every version)

## Result

A field of straight lines in Z^4, of period two, meets every plaquette in
exactly one link. Fixing the gauge on those links leaves each free link with
twelve Dobrushin partners instead of eighteen. In this gauge, at fixed
lattice spacing:

- four-dimensional SU(2) has a unique free-boundary state, reflection
  positive, with exponentially decaying correlations and a transfer-matrix
  gap m ≥ −log(3β_W) for β_W < 1/3 (against 2/9 without gauge fixing); 1/3 is
  the ceiling of every single-link Dobrushin argument after any forest gauge
  fixing;
- with blocks made of the three free links of one plaquette of the gauge,
  four-dimensional SU(2) has the same conclusions past the single-link
  ceiling, for β_W ≤ 0.345, with gap m ≥ −(1/2) log α(β_W), where α is the
  column sum of the block Dobrushin matrix (α(1/3) ≤ 0.95602,
  α(0.345) ≤ 0.99729, constants certified in ball arithmetic);
- for every SU(N) and SO(N) the Hessian of the action on the gauge-fixed
  directions is bounded by 29/2 (against 16), so Bakry–Émery, decay and a gap
  hold for |β| < 1/29 (SU(3): β_W < 9/29);
- four-dimensional SU(3) has the same conclusions for β_W ≤ 3/4, with gap
  m ≥ −log(1.3332 β_W), against 9/32 = 0.281 known before (and 45/64 in the
  previous version of this paper);
- with the same plaquette blocks, four-dimensional SU(3) has gap
  m ≥ −(1/2) log α₃(β_W) for β_W ≤ 3/4, with α₃(3/4) ≤ 0.96521 from
  constants of the one-link measure certified on 841 boxes in ball
  arithmetic, so the gap at β_W = 3/4 rises from 1.1·10⁻⁴ to 0.0177.

## Who did what

Deep Bhattacharjee chose the problem, directed the work, set the format and
the journal style, and ran the computations. Claude (Anthropic), used through
Claude Code under his direction, produced the proofs, the Lean 4 file
`YangMills/StrongCoupling/GaugeFix.lean`, the Python checks and the
certified SU(3) cover, the plaquette-block programs, the figures, the LaTeX text and its reference list
(every reference was checked against the publisher's or Crossref's record),
and this file.

The Anaxia engine of the BLLM system (Deep Bhattacharjee, Zenodo
doi:10.5281/zenodo.23469389, release v3.0.5) first assembled the combination
of a forest gauge fixing with the sharp quarter that gives the SU(2) range;
it did not supply the line field, the free-boundary limit, the ceiling, the
curvature bound or anything in the SU(3) part. Release v3.1.0 of the engine
(doi:10.5281/zenodo.23484160) records the Yang–Mills runs in its failure
log: the narrowing of the target to explicit couplings, the change to bounds
certified box by box, and, as its last Yang–Mills entry, the change to
blocks of several links; the plaquette blocks, the block bound, its SU(3)
version and their certified constants were found and checked without the
engine. It supplied
no step of the proofs; in particular the corrector of degree two that gives
β_W ≤ 3/4 did not come from the engine. The paper says this in a footnote, in
the bibliography and in the data availability section. No other
AI system took part.

## How the result is checked

- **Lean 4 with Mathlib.** `GaugeFix.lean` proves by `decide` that the line
  field meets every plaquette once, that its lines are straight, that every
  free link has twelve partners and the per-link budget of the Hessian bound
  (seven theorems, axioms `propext` at most).
- **Exact arithmetic.** The local blocks of the Hessian bound are checked in
  exact rationals (`strong-coupling/gauge-fixed/checks/curvature/`).
- **Ball arithmetic.** The SU(3) bound with the corrector of degree two is
  evaluated on 2341 boxes that cover every staple sum at r = 3/2, with the
  moments of degree six of the one-link measure from the character expansion
  of the Haar measure, truncation and rounding errors bounded rigorously, the
  corrector polynomials computed exactly with Gaussian-integer coefficients
  and the eigenvalue bounds in Arb through python-flint
  (`strong-coupling/gauge-fixed/checks/su3/deg2/`, about an hour on four
  cores; largest certified value 0.999887 < 1).

- **Plaquette blocks.** `strong-coupling/gauge-fixed/blocks/cover.py` finds
  the sixteen block plaquettes modulo two and checks the partition, the
  three distinct blocks in every other plaquette, the ten outside partners
  and the influence radius on tori of side 4 and 6; `constants.py` and
  `alpha.py` bound the Hessian eigenvalues and the third derivative of the
  log partition function on S^3 in Arb at 120 bits and evaluate α exactly
  at β_W = 1/3 and 0.345. A floating-point search (`float/`, not used in any
  proof) puts the limit of plaquette blocks near β_W ≈ 0.357.

## What is not claimed

The results are about lattice gauge theory at a fixed lattice spacing. They do
not prove the existence of continuum Yang–Mills theory or its mass gap (the
Clay Millennium problem); the paper says where each method stops (single-link SU(2)
at β_W = 1/3, plaquette blocks near 0.357; SU(3) single-link at or below β_W ≈ 0.77 with any bound, after
which blocks of several links are needed) and what remains of the four open problems. The
proofs are written by hand and have not yet been refereed.
