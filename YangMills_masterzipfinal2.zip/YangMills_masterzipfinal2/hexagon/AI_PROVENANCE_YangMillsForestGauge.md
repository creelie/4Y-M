# AI provenance: Mass Gap of Four-Dimensional Lattice Yang–Mills Theory in a Forest Gauge

Authors: Deep Bhattacharjee (corresponding author, ORCID 0000-0003-0466-750X;
formerly EGSPL, Bhubaneswar, Odisha 751030, India, and formerly University of
Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal,
India) and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914; formerly National
Taiwan University, Taipei 106319, Taiwan).

- Paper: https://github.com/creelie/4Y-M/blob/main/preprintYangMillsForestGauge/YangMillsForestGauge.pdf
- Notes, checks and the Lean certificate: https://github.com/creelie/4Y-M (Zenodo concept record https://doi.org/10.5281/zenodo.23444338, which lists every version)

## Result

A field of straight lines in Z^4, of period two, meets every plaquette in
exactly one link. Fixing the gauge on those links leaves each free link with
twelve Dobrushin partners instead of eighteen. In this gauge, at fixed
lattice spacing:

- four-dimensional SU(2) has a unique free-boundary state, reflection
  positive, with exponentially decaying correlations and a transfer-matrix
  gap m ≥ −log(3β_W) for β_W < 1/3 (against 2/9 without gauge fixing); 1/3 is
  the ceiling of every single-link Dobrushin argument after any forest gauge
  fixing;
- for every SU(N) and SO(N) the Hessian of the action on the gauge-fixed
  directions is bounded by 29/2 (against 16), so Bakry–Émery, decay and a gap
  hold for |β| < 1/29 (SU(3): β_W < 9/29);
- four-dimensional SU(3) has the same conclusions for β_W ≤ 45/64 = 0.703,
  with gap m ≥ −log(1.4218 β_W), against 9/32 = 0.281 known before.

## Who did what

Deep Bhattacharjee chose the problem, directed the work, set the format and
the journal style, and ran the computations. Claude (Anthropic), used through
Claude Code under his direction, produced the proofs, the Lean 4 file
`YangMills/StrongCoupling/GaugeFix.lean`, the Python checks and the
certified SU(3) cover, the figures, the LaTeX text and its reference list
(every reference was checked against the publisher's or Crossref's record),
and this file.

The Anaxia engine of the BLLM system (Deep Bhattacharjee, Zenodo
doi:10.5281/zenodo.23469389, release v3.0.5) first assembled the combination
of a forest gauge fixing with the sharp quarter that gives the SU(2) range;
it did not supply the line field, the free-boundary limit, the ceiling, the
curvature bound or anything in the SU(3) part. The paper says this in a
footnote, in the bibliography and in the data availability section. No other
AI system took part.

## How the result is checked

- **Lean 4 with Mathlib.** `GaugeFix.lean` proves by `decide` that the line
  field meets every plaquette once, that its lines are straight, that every
  free link has twelve partners and the per-link budget of the Hessian bound
  (seven theorems, axioms `propext` at most).
- **Exact arithmetic.** The local blocks of the Hessian bound are checked in
  exact rationals (`strong-coupling/gauge-fixed/checks/curvature/`).
- **Ball arithmetic.** The SU(3) bound is evaluated on 865 boxes that cover
  every staple sum, with the moments of the one-link measure from the
  character expansion of the Haar measure, truncation and rounding errors
  bounded rigorously and the eigenvalue bounds in Arb through python-flint
  (`strong-coupling/gauge-fixed/checks/su3/exact/`, about half an hour on
  four cores; largest certified value 0.999657 < 1).

## What is not claimed

The results are about lattice gauge theory at a fixed lattice spacing. They do
not prove the existence of continuum Yang–Mills theory or its mass gap (the
Clay Millennium problem); the paper says where each method stops (SU(2) at
β_W = 1/3; SU(3) single-link near β_W ≈ 0.715 with this gap bound and at or
below 0.77 with any bound) and what remains of the four open problems. The
proofs are written by hand and have not yet been refereed.
