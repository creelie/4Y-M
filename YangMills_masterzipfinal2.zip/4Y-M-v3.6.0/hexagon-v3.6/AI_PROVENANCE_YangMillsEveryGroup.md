# AI provenance: Mass Gap of Four-Dimensional Lattice Yang–Mills Theory for Every Compact Simple Gauge Group

Authors:
- Deep Bhattacharjee, corresponding author. ORCID 0000-0003-0466-750X; itsdeep@live.com, d.bhattacharjee@erl-forschung.de. Formerly Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly Heramba Chandra College, 23/49 Gariahat Road, Golpark, Kolkata 700029 (University of Calcutta, 87/1 College Street, Kolkata 700073), West Bengal, India.
- Ushashi Bhattacharya. ORCID 0009-0002-2254-3914. Formerly National Taiwan University, Taipei 106319, Taiwan.
- James Montgomery Lockwood. Independent Researcher, San Antonio, USA; spectralityworkinggroup@gmail.com.

This is version 3 of Hexagon preprint 2610.00341, first titled "Mass Gap of Four-Dimensional Lattice Yang–Mills Theory in a Forest Gauge".

- Paper: https://github.com/creelie/4Y-M/blob/main/preprintYangMillsForestGauge/YangMillsForestGauge.pdf
- Source, checks and Lean certificate: https://github.com/creelie/4Y-M, release v3.6.0, https://doi.org/10.5281/zenodo.23717210. The concept record https://doi.org/10.5281/zenodo.23444338 lists every version.

## Result

The gauge of four-dimensional lattice Yang–Mills theory is fixed on a period-two field of straight lines that meets every plaquette in exactly one link. Each free link then has twelve Dobrushin partners. The following results hold at fixed lattice spacing.

- **SU(2).** There is a unique free-boundary state. It is reflection positive, its correlations decay exponentially, and its transfer matrix has a gap. This holds for β_W < 1/3 with single links. With blocks made of the three free links of one plaquette, it holds for β_W ≤ 0.345.
- **SU(3).** The same conclusions hold for β_W ≤ 3/4 with single links, and for β_W ≤ 0.76 with plaquette blocks.
- **Every compact simple group.** The gauge-fixed Hessian is bounded by 29/2, and the least Ricci curvature is κ_G = h^∨/(2ℓ_ρ). Together they give uniqueness, clustering and the explicit gap m_G(β) = arccosh(1 + (κ_G/(N|β|) − 29/2)/12) for N|β| < 2κ_G/29.
- **Averaged cubes.** Take a Dobrushin–Shlosman condition D(n, α) on a cube of n⁴ sites, averaged over its translates. It gives a lattice gap of at least log(1/α)/(2n).
- **Conditional continuum step.** Suppose D(n, α) holds with na ≤ ℓ for a fixed physical length ℓ, uniformly along the continuum tuning. Then every continuum limit has a mass gap of at least log(1/α)/(2ℓ).
- **What the cube estimate requires.** The condition holds at strong coupling for every even n above an explicit size. If it holds, the gauge-fixed links of a cube with the identity outside stay at mean distance at least (1 − α)D/3 from the identity, so for every fixed n it fails once β is large. For SU(2) there is an exterior, legal at every coupling, under which one line of links has a ten-step gap at most e^20 24^10 b^15 e^(−b/1280); bounds on single lines uniform in the exterior therefore cannot give the condition.

## Who did what

Text of the contribution: a mix of human-written and AI-generated text.

Human understanding: all parts. The three authors read every proof and approved the final text.

Deep Bhattacharjee chose the problem, directed the work, set the format and ran the computations. The following were produced with AI assistance under his direction: the proofs, the text, the figures, the Lean file, the Python and shell checks, and the reference list. The AI tools were Claude Opus 5.5 in Claude Code, Claude Fable 5.1 with Ultracode, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra.

Every reference was checked against the publisher's, Crossref's or DataCite's record.

The Anaxia engine of the BLLM system first assembled the SU(2) composite (release v3.0.5, doi:10.5281/zenodo.23469389). Release v3.1.0 of the engine records its Yang–Mills runs in a failure log (doi:10.5281/zenodo.23484160). The engine supplied no step of the proofs. The paper says this in its data and code availability section.

## How the result is checked

- **Lean 4 (v4.33.0) with Mathlib.** `YangMills/StrongCoupling/GaugeFix.lean` proves the combinatorics of the line field by `decide`.
- **Exact arithmetic.**
  - The local blocks of the Hessian bound are checked in exact rationals.
  - The curvature table of every compact simple group is checked from the root systems (`strong-coupling/gauge-fixed/checks/groups/ricci.py`, also in `anc/` of the source zip).
- **Ball arithmetic (python-flint, FLINT and Arb).**
  - The SU(3) covers: 2341 boxes at r = 3/2 and 1063 boxes at r = 38/25.
  - The plaquette-block constants for SU(2) and SU(3).
- **Continuum section.** It is analytic. The finite counts of the subsection on the cube estimate (the boundary census, the colouring of the eight lines modulo two, the transverse plaquettes of a line) are rechecked exactly by `strong-coupling/gauge-fixed/checks/cube/cube_requirements.py` (also in `anc/`).

## What is not claimed

The Clay Millennium problem is not solved. The continuum theorem is conditional on two statements that the paper names and does not prove:
- (D) the cube estimate, uniformly in the lattice spacing;
- (E) the existence of a nontrivial Osterwalder–Schrader continuum limit.

The proofs are written by hand and have not yet been refereed.
