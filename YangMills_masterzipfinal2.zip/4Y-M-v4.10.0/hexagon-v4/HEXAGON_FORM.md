# Hexagon submission fields (version 4 of 2610.00341)

Title: Mass Gap of Four-Dimensional Lattice Yang--Mills Theory for Every Compact Simple Group

Abstract: We prove that four-dimensional lattice Yang--Mills theory with any compact simple gauge group has a unique infinite-volume state and an explicit transfer-matrix gap beyond the curvature limit of the ungauged measure, up to beta_W = 0.345 for SU(2) and beta_W = 0.76 for SU(3). A Dobrushin--Shlosman estimate in one cube of fixed physical size gives a mass gap in every continuum limit. We show that the cube needs a side of at least order (beta_W/log beta_W)^{1/4} lattice spacings, and that for SU(2) a cut-off of Balaban's block average composes through the large fields of the Wilson measure up to a scale of the same order. The estimate itself remains open.

Primary subject: math-ph (Mathematical Physics)
Cross-list subjects: math.PR (Probability); hep-lat (High Energy Physics - Lattice)
Keywords: lattice gauge theory; gauge fixing; Dobrushin uniqueness; mass gap
MSC2020: 81T25; 82B20; 60K35; 81T13; 22E30; 58J50; 65G30

Contributor 1 (submitting, corresponding): Deep Bhattacharjee
- ORCID: 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; Formerly, University of Calcutta (Heramba Chandra College), 23/49 Gariahat Road, Golpark, Kolkata 700029, West Bengal, India
- Email: d.bhattacharjee@erl-forschung.de (corresponding), itsdeep@live.com; GitHub contact egspl@proton.me (github.com/creelie)

Contributor 2: Ushashi Bhattacharya
- ORCID: 0009-0002-2254-3914
- Affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan
- Email: rai.bhattacharya.in@gmail.com

Contributor 3: James Montgomery Lockwood
- Affiliation: Independent Researcher, San Antonio, USA
- Email: spectralityworkinggroup@gmail.com (secondary Blaze61029dogQ@proton.me)

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: All parts.

Provenance statement: Deep Bhattacharjee produced the proofs, the text, the figures, the Lean 4 formalization and the Python and shell checks with AI assistance (Claude Opus 5.5 in Claude Code, Claude Fable 5.1, GPT-6.1 Sol Ultra and GPT-6 Astra Ultra). All three authors read every proof and approved the final text. The Anaxia engine of the BLLM system first assembled the combination of the forest gauge with the sharp quarter behind the SU(2) theorem (doi:10.5281/zenodo.23469389; run records doi:10.5281/zenodo.23484160) and supplied no step of the proofs. The paper does not prove the cube estimate along the continuum tuning or the existence of the continuum limit, so it does not solve the Clay Millennium problem, and it says so.

Tools used: Anthropic Claude Opus 5.5 (Claude Code) and Claude Fable 5.1; OpenAI GPT-6.1 Sol Ultra and GPT-6 Astra Ultra; BLLM Anaxia engine v3.0.5 and v3.1.0; Lean 4 (v4.33.0) with Mathlib; Python (NumPy, SciPy, python-flint with FLINT and Arb); C; shell.
arXiv identifier: none.
Formalization: https://github.com/creelie/4Y-M/blob/main/YangMills/StrongCoupling/GaugeFix.lean (release v4.10.0, https://doi.org/10.5281/zenodo.23792627; all versions https://doi.org/10.5281/zenodo.23444338)

Source files or ZIP: YangMillsEveryGroup_final2-tex.zip. It holds the folder YangMillsEveryGroup_final2-tex/ with main.tex, figures/ (seventeen PNG files) and anc/ (the Python checks and figure scripts). It compiles with pdflatex -jobname=output three times; the bibliography is inline, so there is no BibTeX pass.
AI provenance file: AI_PROVENANCE_YangMillsEveryGroup.md
License: CC BY 4.0

Data availability (in the paper): source, programs of the certified computations and the Lean 4 certificate in https://github.com/creelie/4Y-M, release v4.10.0.
Ethics approval: not applicable. Funding: none. Competing interests: none.
Upload order: YangMillsEveryGroup_final2.pdf, YangMillsEveryGroup_final2-tex.zip, AI_PROVENANCE_YangMillsEveryGroup.md, HEXAGON_FORM.md (reference only).
