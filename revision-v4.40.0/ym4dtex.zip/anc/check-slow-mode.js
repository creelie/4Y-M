// Finite-torus checks for the exact counts used in the analytic proof.
function check(block, coarseSide) {
  const side = block * coarseSide;
  const value = base => Number(base.slice(1).some(x => x % block !== 0));
  const shift = (base, direction, amount) => {
    const result = base.slice();
    result[direction] = (result[direction] + amount + side) % side;
    return result;
  };
  let normSquared = 0;
  let curlEnergy = 0;
  let divergenceEnergy = 0;
  for (let x0 = 0; x0 < side; x0++) {
    for (let x1 = 0; x1 < side; x1++) {
      for (let x2 = 0; x2 < side; x2++) {
        for (let x3 = 0; x3 < side; x3++) {
          const base = [x0, x1, x2, x3];
          normSquared += value(base);
          for (let direction = 1; direction < 4; direction++) {
            const curl = value(base) - value(shift(base, direction, 1));
            curlEnergy += curl * curl;
          }
          if (base.filter(x => x % block !== 0).length > 1) {
            const divergence = value(base) - value(shift(base, 0, -1));
            divergenceEnergy += divergence * divergence;
          }
        }
      }
    }
  }
  if (normSquared !== (block ** 4 - block) * coarseSide ** 4 ||
      curlEnergy !== 6 * block * coarseSide ** 4 || divergenceEnergy !== 0) {
    throw new Error(`Count mismatch for block ${block}`);
  }
  return { block, coarseSide, normSquared, curlEnergy, divergenceEnergy };
}
process.stdout.write(JSON.stringify([3, 4, 5].map(block => check(block, 3)), null, 2));
